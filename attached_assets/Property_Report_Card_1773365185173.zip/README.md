
  # Property Report Card

  This is a code bundle for Property Report Card. The original project is available at https://www.figma.com/design/gv0XUhEyRfDnWJKEkb1H86/Property-Report-Card.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
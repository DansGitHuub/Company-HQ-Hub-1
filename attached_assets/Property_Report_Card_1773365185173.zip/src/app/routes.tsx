// Routes configuration

import { createBrowserRouter } from 'react-router';
import RootLayout from './layouts/RootLayout';
import Dashboard from './screens/Dashboard';
import PropertySetup from './screens/PropertySetup';
import CategoryList from './screens/CategoryList';
import CategoryDetail from './screens/CategoryDetail';
import Review from './screens/Review';
import Report from './screens/Report';

export const router = createBrowserRouter([
  {
    path: '/',
    element: <RootLayout />,
    children: [
      {
        index: true,
        element: <Dashboard />,
      },
      {
        path: 'property-setup',
        element: <PropertySetup />,
      },
      {
        path: 'assessment/:id',
        element: <CategoryList />,
      },
      {
        path: 'assessment/:id/category/:categoryId',
        element: <CategoryDetail />,
      },
      {
        path: 'assessment/:id/review',
        element: <Review />,
      },
      {
        path: 'report/:id',
        element: <Report />,
      },
    ],
  },
]);
// Root layout component that wraps all routes

import { Outlet } from 'react-router';
import { Toaster } from '../components/ui/sonner';

export default function RootLayout() {
  return (
    <>
      <Outlet />
      <Toaster />
    </>
  );
}